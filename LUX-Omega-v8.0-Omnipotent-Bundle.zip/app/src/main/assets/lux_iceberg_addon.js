(function(){
  const B = "http://127.0.0.1:8765";
  const st = {
    colabUrl: localStorage.getItem("lux_colab_url") || "",
    colabNotebook: localStorage.getItem("lux_colab_nb") || "https://colab.research.google.com/",
    syncChannel: localStorage.getItem("lux_sync_ch") || "lux-omega-kauan-v55",
    llmProvider: localStorage.getItem("lux_llm_prov") || "pollinations",
    llmKey: localStorage.getItem("lux_llm_key") || "",
    falKey: localStorage.getItem("lux_fal_key") || "",
    voiceEngine: localStorage.getItem("lux_voice_eng") || "f5",
    autoWake: localStorage.getItem("lux_autowake") !== "0",
    inCall: false
  };
  let wakingTimer = null;

  async function api(p, opt){ const r = await fetch(B + p, { ...opt, headers: {"Content-Type":"application/json"} }); return await r.json(); }

  function card(t, h){
    const d = document.createElement("div");
    d.style.cssText = "margin:10px 0;background:#0d1422;border:1px solid #1e3a5f;border-left:4px solid #06b6d4;border-radius:8px;padding:12px;font-size:13px";
    d.innerHTML = `<div style="color:#22d3ee;font-weight:bold;margin-bottom:6px">⚡ ${t}</div>${h}`;
    document.getElementById("chat").appendChild(d);
    window.scrollTo(0, document.body.scrollHeight);
  }

  const callBtn = document.getElementById("call-btn");
  if (callBtn) {
    callBtn.onclick = () => {
      if (!window.AndroidBridge) return;
      if (!st.inCall) {
        st.inCall = true;
        callBtn.innerText = "🔴 Encerrar";
        callBtn.style.background = "#dc2626";
        window.AndroidBridge.startVoiceCall();
      } else {
        st.inCall = false;
        callBtn.innerText = "🎙️ Ligar";
        callBtn.style.background = "#059669";
        window.AndroidBridge.stopVoiceCall();
      }
    };
  }

  window.LUX_ON_VOICE_STATE = (state) => {
    if (!callBtn || !st.inCall) return;
    if (state === "listening") callBtn.innerText = "👂 Ouvindo...";
    else if (state === "thinking") callBtn.innerText = "🧠 Pensando...";
    else if (state === "off") { st.inCall = false; callBtn.innerText = "🎙️ Ligar"; callBtn.style.background = "#059669"; }
  };

  window.LUX_ON_VOICE_TEXT = async (spoken) => {
    card("🗣️ Você disse", `<i>"${spoken}"</i>`);
    if (!(await handleDirectChatCommand(spoken, null))) {
      await askInstantLlm(spoken, true);
    }
  };

  async function runPhoneAgent(goal){
    if (window.AndroidBridge && !window.AndroidBridge.isAccessibilityEnabled()) {
      card("🔐 Permissão Necessária", `Ative <b>LUX-Ω v8.0</b> nas configurações de Acessibilidade para controlar outros apps.<br><br><button onclick="window.AndroidBridge.openAccessibilitySettings()" style="background:#0284c7;color:#fff;border:none;padding:8px 12px;border-radius:6px">Abrir Acessibilidade Agora</button>`);
      return;
    }
    card("📱 Agente Android Iniciado", `Objetivo: <b>${goal}</b>`);
    for (let step = 1; step <= 6; step++) {
      const scr = await api("/phone/screen", {method:"GET"});
      if (!scr.ok) { card("Erro Tela", scr.error); return; }
      const agentPrompt =
        `Você é um agente autônomo controlando um celular Android. Objetivo: "${goal}".\n` +
        `App atual: ${scr.package}. Elementos visíveis: ${JSON.stringify((scr.elements || []).slice(0, 45))}\n` +
        `Responda APENAS um JSON válido sem markdown: {"action":"open_app|click_text|type_text|swipe|back|home|done","value":"texto ou nome do app","reason":"curto"}`;
      const llm = await api("/llm/cloud", {method:"POST", body:JSON.stringify({prompt: agentPrompt, provider: st.llmProvider, api_key: st.llmKey})});
      if (!llm.ok) { card("Erro Agente", llm.error); return; }
      let cmd;
      try {
        const m = llm.text.match(/\{[\s\S]*\}/);
        cmd = JSON.parse(m ? m[0] : llm.text);
      } catch (e) { card("Falha Parse Agente", llm.text); return; }

      if (cmd.action === "done") {
        card("✅ Tarefa Concluída no Celular", cmd.reason || "Ação finalizada.");
        if (st.inCall && window.AndroidBridge) window.AndroidBridge.speakText(cmd.reason || "Pronto.");
        return;
      }
      await api("/phone/action", {method:"POST", body:JSON.stringify({action: cmd.action, value: cmd.value || ""})});
      await new Promise(r => setTimeout(r, 1400));
    }
    card("⏹️ Limite de Passos", "O agente executou 6 ações na tela.");
  }

  async function syncColab(){
    const d = await api("/colab/sync", {method:"POST", body:JSON.stringify({channel: st.syncChannel})});
    const badge = document.getElementById("colab-badge");
    if (d.ok && d.url) {
      st.colabUrl = d.url;
      localStorage.setItem("lux_colab_url", d.url);
      if (badge) { badge.innerText = "Colab GPU: ON"; badge.style.color = "#34d399"; }
      return d.url;
    }
    if (badge) { badge.innerText = "Colab: Stand-by"; badge.style.color = "#94a3b8"; }
    return "";
  }

  async function ensureColabAwake(taskFn){
    if (st.colabUrl) {
      try {
        const h = await fetch(st.colabUrl.replace(/\/+$/, "") + "/health");
        if (h.ok) return true;
      } catch(e) { st.colabUrl = ""; }
    }
    const fresh = await syncColab();
    if (fresh) return true;

    if (st.autoWake && window.AndroidBridge && st.colabNotebook.includes("colab.research.google.com")) {
      card("🚀 Acordando Colab Automaticamente...", "Seu pedido entrou na fila e será executado assim que a GPU iniciar.");
      window.AndroidBridge.wakeColab(st.colabNotebook);
      if (wakingTimer) clearInterval(wakingTimer);
      let attempts = 0;
      wakingTimer = setInterval(async () => {
        attempts++;
        const url = await syncColab();
        if (url) {
          clearInterval(wakingTimer);
          wakingTimer = null;
          if (window.AndroidBridge) window.AndroidBridge.hideColab();
          card("✅ GPU Conectada!", "Executando tarefa da fila...");
          await taskFn();
        } else if (attempts >= 40) {
          clearInterval(wakingTimer);
          wakingTimer = null;
          card("⏳ Tempo Limite", "Verifique o login Google na janela interna do Colab e toque em Sincronizar.");
        }
      }, 4000);
    } else {
      card("⚡ Colab Hibernando", `<a href="${st.colabNotebook}" style="color:#38bdf8;font-weight:bold">Abrir Notebook Colab</a> e clique em Sincronizar.`);
    }
    return false;
  }

  async function runMemoryIngest(text, attachedFile){
    if (!(await ensureColabAwake(() => runMemoryIngest(text, attachedFile)))) return;
    card("🧠 Indexando na Memória do Google Drive...", attachedFile ? `Arquivo: <b>${attachedFile.name}</b>` : "Nota textual");
    const fd = new FormData();
    fd.append("text", text || "");
    if (attachedFile) fd.append("file", attachedFile);
    try {
      const res = await fetch(st.colabUrl.replace(/\/+$/, "") + "/memory/ingest", { method: "POST", body: fd });
      const d = await res.json();
      if (!d.ok) { card("Erro Memória", d.error); return; }
      card("✅ Memória Atualizada no Drive", `Fonte: <b>${d.source}</b> • Blocos vetoriais: <b>${d.chunks_indexed}</b>`);
    } catch (e) { st.colabUrl = ""; await ensureColabAwake(() => runMemoryIngest(text, attachedFile)); }
  }

  async function runMemoryQuery(query){
    if (!(await ensureColabAwake(() => runMemoryQuery(query)))) return;
    card("🔍 Consultando Memória Persistente...", `<i>"${query}"</i>`);
    const d = await api("/colab/proxy", {method:"POST", body:JSON.stringify({colab_url: st.colabUrl, endpoint: "/memory/query", payload: {query}})});
    if (!d.ok) { card("Erro Consulta", d.error || "Falha na consulta."); return; }
    let srcHtml = "";
    (d.sources || []).forEach(s => {
      srcHtml += `<div style="margin-top:6px;padding:6px;background:#070b14;border-radius:6px;font-size:11px;color:#94a3b8"><b style="color:#a78bfa">${s.source}</b> (${Math.round(s.score*100)}%): ${s.snippet}</div>`;
    });
    card("🧠 Resposta da Memória RAG", `<div style="white-space:pre-wrap;line-height:1.5">${d.answer}</div>${srcHtml}`);
    if (st.inCall && window.AndroidBridge) window.AndroidBridge.speakText(d.answer);
  }

  async function askInstantLlm(prompt, speakOut){
    const d = await api("/llm/cloud", {method:"POST", body:JSON.stringify({prompt, provider: st.llmProvider, api_key: st.llmKey})});
    if (d.ok) {
      card(`🧠 ${d.provider}`, `<div style="white-space:pre-wrap;line-height:1.5">${d.text}</div>`);
      if ((speakOut || st.inCall) && window.AndroidBridge) window.AndroidBridge.speakText(d.text);
    } else {
      card("Erro IA Nuvem", d.error);
    }
  }

  async function runVoiceClone(rawInput, attachedFile){
    if (!(await ensureColabAwake(() => runVoiceClone(rawInput, attachedFile)))) return;
    let text = rawInput, mediaUrl = "";
    if (rawInput.includes("|")) { const p = rawInput.split("|"); mediaUrl = p[0].trim(); text = p.slice(1).join("|").trim(); }
    if (!attachedFile && !mediaUrl) { card("Falta Mídia", "Toque em <b>📎</b> ou use <code>clonar voz URL | texto</code>"); return; }
    card("🎙️ Estúdio de Voz...", `<i>"${text}"</i>`);
    const fd = new FormData();
    fd.append("text", text); fd.append("engine", st.voiceEngine); fd.append("media_url", mediaUrl);
    if (attachedFile) fd.append("file", attachedFile);
    try {
      const res = await fetch(st.colabUrl.replace(/\/+$/, "") + "/voice_clone", { method: "POST", body: fd });
      const d = await res.json();
      if (!d.ok) { card("Erro Voz", `<span style="color:#f87171">${d.error}</span>`); return; }
      card("✅ Voz Masterizada", `<audio src="${d.url}" controls autoplay style="width:100%"></audio>`);
    } catch (e) { st.colabUrl = ""; await ensureColabAwake(() => runVoiceClone(rawInput, attachedFile)); }
  }

  async function runFaceSwap(targetName, attachedFile){
    if (!(await ensureColabAwake(() => runFaceSwap(targetName, attachedFile)))) return;
    if (!attachedFile) { card("Falta Mídia", "Toque em <b>📎</b> e anexe foto/vídeo antes de enviar."); return; }
    card("🎭 Face Swap Multi-Ângulo HD", `Alvo: <b>${targetName}</b>`);
    const fd = new FormData();
    fd.append("target_name", targetName); fd.append("media_file", attachedFile);
    try {
      const res = await fetch(st.colabUrl.replace(/\/+$/, "") + "/face_swap", { method: "POST", body: fd });
      const d = await res.json();
      if (!d.ok) { card("Erro Face Swap", `<span style="color:#f87171">${d.error}</span>`); return; }
      if (d.type === "video") card("✅ Vídeo HD", `<video src="${d.url}" controls autoplay style="width:100%;border-radius:6px"></video>`);
      else card("✅ Imagem HD", `<img src="${d.url}" style="width:100%;border-radius:6px"/>`);
    } catch (e) { st.colabUrl = ""; await ensureColabAwake(() => runFaceSwap(targetName, attachedFile)); }
  }

  async function runDubVideo(targetName, text, attachedFile){
    if (!(await ensureColabAwake(() => runDubVideo(targetName, text, attachedFile)))) return;
    if (!attachedFile) { card("Falta Mídia", "Toque em <b>📎</b> e anexe o vídeo ou foto-retrato base."); return; }
    card("🎬 Dublagem Studio 3D / 1080p", `Alvo: <b>${targetName}</b>`);
    const fd = new FormData();
    fd.append("target_name", targetName); fd.append("text", text); fd.append("video_file", attachedFile);
    try {
      const res = await fetch(st.colabUrl.replace(/\/+$/, "") + "/dub_video", { method: "POST", body: fd });
      const d = await res.json();
      if (!d.ok) { card("Erro Dublagem", `<span style="color:#f87171">${d.error}</span>`); return; }
      card("✅ Vídeo Dublado 1080p", `<video src="${d.url}" controls autoplay style="width:100%;border-radius:6px"></video>`);
    } catch (e) { st.colabUrl = ""; await ensureColabAwake(() => runDubVideo(targetName, text, attachedFile)); }
  }

  async function runColabTool(tool, params){
    if (!(await ensureColabAwake(() => runColabTool(tool, params)))) return;
    if (tool === "video_story") card("🎞️ Gerando História Encadeada Consistente...", "Renderizando cenas sequenciais com âncora visual...");
    const d = await api("/colab/proxy", {method:"POST", body:JSON.stringify({colab_url: st.colabUrl, endpoint: "/run", payload: {tool, params}})});
    if (!d.ok) { card("Erro GPU", d.error || "Falha na execução."); return; }
    if (d.type === "video") card("🎬 Vídeo 1080p Finalizado", `<video src="${d.url}" controls autoplay style="width:100%;border-radius:6px"></video>`);
    else card(`⚡ GPU (${tool})`, `<pre style="white-space:pre-wrap;background:#070b14;padding:8px;max-height:260px;overflow:auto">${d.text || d.clean_text || d.stdout || JSON.stringify(d, null, 2)}</pre>`);
  }

  async function runCloudMedia(mode, prompt){
    const prov = (mode === "video" && st.falKey) ? "fal" : "pollinations";
    const d = await api("/media/cloud", {method:"POST", body:JSON.stringify({provider: prov, api_key: st.falKey, mode, prompt})});
    if (!d.ok) { card("Erro Mídia", d.error); return; }
    if (d.type === "video") card(`🎬 ${d.provider}`, `<video src="${d.url}" controls autoplay style="width:100%;border-radius:6px"></video>`);
    else card(`🎨 ${d.provider}`, `<img src="${d.url}" style="width:100%;border-radius:6px"/>`);
  }

  async function executeIcebergSearch(q){
    const d = await api("/search", {method:"POST", body:JSON.stringify({query:q})});
    let h = `<div style="color:#94a3b8;margin-bottom:6px">${d.total_results} resultados (${d.elapsed_ms}ms)</div>`;
    for (const [k, arr] of Object.entries(d.by_layer || {})) {
      if (!arr.length) continue;
      h += `<div style="color:#38bdf8;font-weight:bold;margin-top:6px">▸ ${k}</div><ul>`;
      arr.forEach(i => h += `<li><a href="${i.url}" style="color:#67e8f9">${i.title}</a></li>`);
      h += `</ul>`;
    }
    card("Busca Multi-Camada", h);
  }

  async function executeOsintInspect(u){
    const d = await api("/inspect", {method:"POST", body:JSON.stringify({url:u})});
    if (!d.ok) { card("Erro OSINT", `<span style="color:#f87171">${d.route}: ${d.error}</span>`); return; }
    card("Inspeção OSINT", `<b>Rota:</b> ${d.route}<br><b>Título:</b> ${d.title}<pre style="white-space:pre-wrap;background:#070b14;padding:8px;max-height:200px;overflow:auto">${d.clean_text}</pre>`);
  }

  async function handleDirectChatCommand(t, file){
    let m;
    if ((m = t.match(/^(?:celular|android|abrir\s+app)\s+(.+)$/i))) { await runPhoneAgent(m[1]); return true; }
    if ((m = t.match(/^(?:criar\s+historia|video\s+longo|historia\s+video)\s+(.+)$/i))) { await runColabTool("video_story", {prompt: m[1]}); return true; }
    if (/^memorizar$/i.test(t) && file) { await runMemoryIngest("", file); return true; }
    if ((m = t.match(/^(?:memorizar|salvar\s+na\s+memoria)\s+(.+)$/i))) { await runMemoryIngest(m[1], file); return true; }
    if ((m = t.match(/^(?:lembrar|consultar\s+memoria|buscar\s+na\s+memoria)\s+(.+)$/i))) { await runMemoryQuery(m[1]); return true; }
    if ((m = t.match(/^(?:dublar|trocar\s+rosto\s+e\s+falar)\s+([^|]+)\|\s*(.+)$/i))) { await runDubVideo(m[1].trim(), m[2].trim(), file); return true; }
    if ((m = t.match(/^(?:clonar\s+voz|copiar\s+voz)\s+(.+)$/i))) { await runVoiceClone(m[1], file); return true; }
    if ((m = t.match(/^(?:trocar\s+rosto|colocar\s+(?:o\s+)?rosto\s+d[oa]s?)\s+(.+)$/i))) { await runFaceSwap(m[1], file); return true; }
    if ((m = t.match(/^(?:pesquisar\s+iceberg|buscar\s+osint|pesquisar)\s+(.+)$/i))) { await executeIcebergSearch(m[1]); return true; }
    if ((m = t.match(/^(?:inspecionar\s+url|acessar\s+onion|acessar\s+i2p)\s+(\S+)$/i))) { await executeOsintInspect(m[1]); return true; }
    if ((m = t.match(/^(?:gerar\s+imagem|criar\s+imagem|desenhar)\s+(.+)$/i))) { await runCloudMedia("image", m[1]); return true; }
    if ((m = t.match(/^gerar\s+video\s+gpu\s+(.+)$/i))) { await runColabTool("video_gpu", {prompt: m[1]}); return true; }
    if ((m = t.match(/^gerar\s+video\s+(.+)$/i))) { await runCloudMedia("video", m[1]); return true; }
    if ((m = t.match(/^(?:transcrever|legendar)\s+(\S+)$/i))) { await runColabTool("whisper", {url: m[1]}); return true; }
    if ((m = t.match(/^(?:crawl|playwright|extrair\s+site)\s+(\S+)$/i))) { await runColabTool("crawl4ai", {url: m[1]}); return true; }
    if ((m = t.match(/^ia\s+gpu\s+(.+)$/i))) { await runColabTool("llm_gpu", {prompt: m[1]}); return true; }
    if ((m = t.match(/^ia\s+(.+)$/i))) { await askInstantLlm(m[1], st.inCall); return true; }
    if ((m = t.match(/^python\s+(.+)$/i))) { await runColabTool("python", {code: m[1]}); return true; }
    if ((m = t.match(/^mcp\s+(.+)$/i))) { await runColabTool("mcp", {server: m[1]}); return true; }
    if ((m = t.match(/(https?:\/\/\S+\.(?:onion|i2p)\S*)/i))) { await executeOsintInspect(m[1]); return true; }
    return false;
  }

  const dock = document.createElement("div");
  dock.style.cssText = "position:fixed;bottom:62px;right:12px;z-index:999";
  dock.innerHTML = `
    <button id="b2" style="background:#1e293b;color:#38bdf8;border:1px solid #334155;border-radius:20px;padding:6px 12px">⚙ Config 2B</button>
    <div id="p2" style="display:none;background:#0b1220;border:1px solid #1e3a5f;padding:12px;border-radius:10px;margin-top:6px;width:295px;font-size:12px">
      <div style="font-weight:bold;color:#22d3ee;margin-bottom:6px">LUX-Ω v8.0 Omnipotent</div>
      <input id="c-nb" placeholder="Link exato do Notebook Colab" value="${st.colabNotebook}" style="width:100%;box-sizing:border-box;margin-bottom:6px;padding:6px;font-size:11px"/>
      <label style="display:flex;align-items:center;gap:6px;margin-bottom:6px;color:#cbd5e1">
        <input type="checkbox" id="c-aw" ${st.autoWake ? "checked" : ""}/> Auto-Ativar Colab sob demanda
      </label>
      <select id="c-ve" style="width:100%;background:#070b14;color:#fff;border:1px solid #334155;padding:6px;border-radius:6px;margin-bottom:6px">
        <option value="f5">Voz Studio: F5-TTS + Auto-Whisper</option>
        <option value="xtts">Voz Studio: XTTS-v2 Multilíngue</option>
      </select>
      <select id="c-lp" style="width:100%;background:#070b14;color:#fff;border:1px solid #334155;padding:6px;border-radius:6px;margin-bottom:6px">
        <option value="pollinations">Cérebro Nuvem: Grátis (0 Tokens)</option>
        <option value="groq">Cérebro Nuvem: Groq (Llama 3.3 70B)</option>
        <option value="openrouter">Cérebro Nuvem: OpenRouter (DeepSeek R1)</option>
      </select>
      <input id="c-lk" type="password" placeholder="API Key Groq/OpenRouter (Opcional)" value="${st.llmKey}" style="width:100%;box-sizing:border-box;margin-bottom:6px;padding:6px;font-size:11px"/>
      <button id="c-acc" style="width:100%;background:#d97706;color:#fff;border:none;padding:7px;border-radius:6px;margin-bottom:6px">📱 Ativar Acessibilidade Android</button>
      <button id="c-open" style="width:100%;background:#7c3aed;color:#fff;border:none;padding:7px;border-radius:6px;margin-bottom:6px">🔑 Abrir Colab Interno (Login Único)</button>
      <button id="c-save" style="width:100%;background:#059669;color:#fff;border:none;padding:7px;border-radius:6px;margin-bottom:6px">Salvar & Sincronizar</button>
      <button id="tp" style="width:100%;background:#0284c7;color:#fff;border:none;padding:7px;border-radius:6px">Testar Proxies & Acessibilidade</button>
      <div id="st" style="margin-top:6px;color:#94a3b8"></div>
    </div>`;
  document.body.appendChild(dock);
  document.getElementById("c-ve").value = st.voiceEngine;
  document.getElementById("c-lp").value = st.llmProvider;
  document.getElementById("b2").onclick = () => { const p = document.getElementById("p2"); p.style.display = p.style.display === "none" ? "block" : "none"; };
  document.getElementById("c-acc").onclick = () => { if (window.AndroidBridge) window.AndroidBridge.openAccessibilitySettings(); };
  document.getElementById("c-open").onclick = () => { if (window.AndroidBridge) window.AndroidBridge.wakeColab(st.colabNotebook); };
  document.getElementById("c-save").onclick = async () => {
    st.colabNotebook = document.getElementById("c-nb").value.trim();
    st.autoWake = document.getElementById("c-aw").checked;
    st.voiceEngine = document.getElementById("c-ve").value;
    st.llmProvider = document.getElementById("c-lp").value;
    st.llmKey = document.getElementById("c-lk").value.trim();
    localStorage.setItem("lux_colab_nb", st.colabNotebook);
    localStorage.setItem("lux_autowake", st.autoWake ? "1" : "0");
    localStorage.setItem("lux_voice_eng", st.voiceEngine);
    localStorage.setItem("lux_llm_prov", st.llmProvider);
    localStorage.setItem("lux_llm_key", st.llmKey);
    await syncColab();
  };
  document.getElementById("tp").onclick = async () => {
    const d = await api("/health", {method:"GET"});
    document.getElementById("st").innerText = `Tor: ${d.proxies.tor_socks5h.status} | I2P: ${d.proxies.i2pd_http.status} | Acessibilidade: ${d.accessibility}`;
  };
  syncColab();
  window.LUX_ICEBERG = { executeIcebergSearch, executeOsintInspect, handleDirectChatCommand, askInstantLlm, syncColab };
})();
