package com.luxomega.iceberg;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.webkit.*;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
  private WebView webView;
  private WebView colabWebView;
  private LinearLayout colabOverlay;
  private IcebergBridgeServer bridge;
  private ValueCallback<Uri[]> filePathCallback;
  private SpeechRecognizer speechRecognizer;
  private TextToSpeech tts;
  private volatile boolean callModeActive = false;

  @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    bridge = new IcebergBridgeServer(8765);
    bridge.start();

    CookieManager.getInstance().setAcceptCookie(true);
    initVoiceEngine();

    FrameLayout root = new FrameLayout(this);
    root.setBackgroundColor(Color.parseColor("#070b14"));

    webView = new WebView(this);
    webView.setBackgroundColor(Color.parseColor("#070b14"));
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowFileAccessFromFileURLs(true);
    s.setAllowUniversalAccessFromFileURLs(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    webView.addJavascriptInterface(new LuxNativeBridge(), "AndroidBridge");

    webView.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String u = request.getUrl().toString();
        if (u.contains("colab.research.google.com")) {
          openColabOverlay(u, true);
          return true;
        }
        return false;
      }
    });

    webView.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb, FileChooserParams params) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        filePathCallback = cb;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "audio/*", "video/*", "application/pdf", "text/*"});
        startActivityForResult(Intent.createChooser(i, "Selecionar Arquivo ou Mídia"), 1001);
        return true;
      }
    });

    colabOverlay = new LinearLayout(this);
    colabOverlay.setOrientation(LinearLayout.VERTICAL);
    colabOverlay.setBackgroundColor(Color.parseColor("#0b1220"));
    colabOverlay.setVisibility(View.GONE);

    LinearLayout topBar = new LinearLayout(this);
    topBar.setOrientation(LinearLayout.HORIZONTAL);
    topBar.setPadding(24, 18, 24, 18);
    topBar.setGravity(Gravity.CENTER_VERTICAL);
    topBar.setBackgroundColor(Color.parseColor("#111827"));

    TextView title = new TextView(this);
    title.setText("⚡ Auto-Ativando GPU Colab...");
    title.setTextColor(Color.parseColor("#38bdf8"));
    title.setTextSize(14f);
    title.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

    Button closeBtn = new Button(this);
    closeBtn.setText("Minimizar ✕");
    closeBtn.setTextColor(Color.WHITE);
    closeBtn.setBackgroundColor(Color.parseColor("#334155"));
    closeBtn.setOnClickListener(v -> colabOverlay.setVisibility(View.GONE));

    topBar.addView(title);
    topBar.addView(closeBtn);

    colabWebView = new WebView(this);
    WebSettings cs = colabWebView.getSettings();
    cs.setJavaScriptEnabled(true);
    cs.setDomStorageEnabled(true);
    cs.setDatabaseEnabled(true);
    cs.setUserAgentString("Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
    CookieManager.getInstance().setAcceptThirdPartyCookies(colabWebView, true);

    colabWebView.setWebViewClient(new WebViewClient() {
      @Override
      public void onPageFinished(WebView view, String url) {
        if (url != null && url.contains("colab.research.google.com")) {
          String autoRunJs =
            "(function(){" +
            "  if(window.__luxAutoRan) return;" +
            "  function queryDeep(root, sel){" +
            "    if(!root) return null;" +
            "    const direct = root.querySelector(sel);" +
            "    if(direct) return direct;" +
            "    const all = root.querySelectorAll('*');" +
            "    for(const el of all){" +
            "      if(el.shadowRoot){" +
            "        const found = queryDeep(el.shadowRoot, sel);" +
            "        if(found) return found;" +
            "      }" +
            "    }" +
            "    return null;" +
            "  }" +
            "  let tries = 0;" +
            "  const iv = setInterval(()=>{" +
            "    tries++;" +
            "    try {" +
            "      const okBtn = queryDeep(document, 'md-text-button[dialogaction=\"ok\"], mwc-button[dialogaction=\"ok\"], #ok, button[id=\"ok\"]');" +
            "      if(okBtn) okBtn.click();" +
            "      const runBtn = queryDeep(document, 'colab-run-button');" +
            "      if(runBtn && runBtn.shadowRoot){" +
            "        const inner = runBtn.shadowRoot.querySelector('#run-button');" +
            "        if(inner && !runBtn.hasAttribute('running')){" +
            "          inner.click();" +
            "          window.__luxAutoRan = true;" +
            "        }" +
            "      }" +
            "      if(!window.__luxAutoRan){" +
            "        document.dispatchEvent(new KeyboardEvent('keydown', {key:'F9', code:'F9', keyCode:123, which:123, ctrlKey:true, bubbles:true}));" +
            "      }" +
            "    } catch(e) {}" +
            "    if(window.__luxAutoRan || tries > 22) clearInterval(iv);" +
            "  }, 1500);" +
            "})();";
          view.evaluateJavascript(autoRunJs, null);
        }
      }
    });

    colabOverlay.addView(topBar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    colabOverlay.addView(colabWebView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

    root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    root.addView(colabOverlay, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

    setContentView(root);
    webView.loadUrl("file:///android_asset/index.html");
  }

  private void initVoiceEngine() {
    tts = new TextToSpeech(this, status -> {
      if (status == TextToSpeech.SUCCESS) {
        tts.setLanguage(new Locale("pt", "BR"));
        tts.setSpeechRate(1.08f);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
          @Override public void onStart(String id) {}
          @Override public void onError(String id) { if (callModeActive) runOnUiThread(() -> listenOnce()); }
          @Override public void onDone(String id) { if (callModeActive) runOnUiThread(() -> listenOnce()); }
        });
      }
    });
  }

  private void listenOnce() {
    if (!callModeActive) return;
    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2002);
      return;
    }
    if (speechRecognizer != null) speechRecognizer.destroy();
    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
    speechRecognizer.setRecognitionListener(new RecognitionListener() {
      @Override public void onReadyForSpeech(Bundle b) { evalJs("window.LUX_ON_VOICE_STATE && window.LUX_ON_VOICE_STATE('listening')"); }
      @Override public void onBeginningOfSpeech() {}
      @Override public void onRmsChanged(float v) {}
      @Override public void onBufferReceived(byte[] b) {}
      @Override public void onEndOfSpeech() { evalJs("window.LUX_ON_VOICE_STATE && window.LUX_ON_VOICE_STATE('thinking')"); }
      @Override public void onError(int err) { if (callModeActive) webView.postDelayed(() -> listenOnce(), 900); }
      @Override public void onPartialResults(Bundle b) {}
      @Override public void onEvent(int t, Bundle b) {}
      @Override public void onResults(Bundle results) {
        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list != null && !list.isEmpty()) {
          String said = list.get(0).replace("\\", "\\\\").replace("'", "\\'");
          evalJs("window.LUX_ON_VOICE_TEXT && window.LUX_ON_VOICE_TEXT('" + said + "')");
        } else if (callModeActive) {
          listenOnce();
        }
      }
    });
    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
    speechRecognizer.startListening(intent);
  }

  private void evalJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

  private void openColabOverlay(String url, boolean autoRun) {
    runOnUiThread(() -> {
      colabOverlay.setVisibility(View.VISIBLE);
      colabWebView.evaluateJavascript("window.__luxAutoRan = false;", null);
      String cur = colabWebView.getUrl();
      if (cur == null || !cur.equals(url)) colabWebView.loadUrl(url);
      else if (autoRun) colabWebView.reload();
    });
  }

  public class LuxNativeBridge {
    @JavascriptInterface public void wakeColab(String url) { openColabOverlay(url, true); }
    @JavascriptInterface public void hideColab() { runOnUiThread(() -> colabOverlay.setVisibility(View.GONE)); }
    @JavascriptInterface public void openAccessibilitySettings() {
      startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    @JavascriptInterface public boolean isAccessibilityEnabled() { return LuxAccessibilityService.instance != null; }
    @JavascriptInterface public void startVoiceCall() { callModeActive = true; runOnUiThread(() -> listenOnce()); }
    @JavascriptInterface public void stopVoiceCall() {
      callModeActive = false;
      runOnUiThread(() -> {
        if (speechRecognizer != null) speechRecognizer.cancel();
        if (tts != null) tts.stop();
        evalJs("window.LUX_ON_VOICE_STATE && window.LUX_ON_VOICE_STATE('off')");
      });
    }
    @JavascriptInterface public void speakText(String text) {
      if (tts != null) {
        String clean = text.replaceAll("[*#`_~]", "").trim();
        if (clean.length() > 600) clean = clean.substring(0, 600);
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "lux_utt");
      }
    }
  }

  @Override
  public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
    if (req == 2002 && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && callModeActive) listenOnce();
  }

  @Override
  protected void onActivityResult(int req, int res, Intent data) {
    if (req == 1001 && filePathCallback != null) {
      Uri[] results = (res == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
      filePathCallback.onReceiveValue(results);
      filePathCallback = null;
    }
  }

  @Override
  public void onBackPressed() {
    if (colabOverlay != null && colabOverlay.getVisibility() == View.VISIBLE) {
      colabOverlay.setVisibility(View.GONE);
      return;
    }
    super.onBackPressed();
  }

  @Override protected void onDestroy() {
    callModeActive = false;
    if (speechRecognizer != null) speechRecognizer.destroy();
    if (tts != null) tts.shutdown();
    if (bridge != null) bridge.stopServer();
    super.onDestroy();
  }
}
