package com.luxomega.iceberg;
import android.accessibilityservice.AccessibilityService;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.regex.*;
import javax.net.ssl.*;

public class IcebergBridgeServer extends Thread {
  private final int port;
  private volatile boolean running = true;
  private ServerSocket ss;
  private final ExecutorService pool = Executors.newCachedThreadPool();

  public IcebergBridgeServer(int port) { this.port = port; setDaemon(true); }
  public void stopServer() { running = false; try { if (ss != null) ss.close(); } catch (Exception ignored) {} pool.shutdownNow(); }

  @Override public void run() {
    try {
      ss = new ServerSocket();
      ss.setReuseAddress(true);
      ss.bind(new InetSocketAddress("127.0.0.1", port));
      while (running) { Socket c = ss.accept(); pool.submit(() -> handle(c)); }
    } catch (Exception ignored) {}
  }

  private void handle(Socket c) {
    try (Socket s = c; InputStream in = new BufferedInputStream(s.getInputStream()); OutputStream out = s.getOutputStream()) {
      String reqLine = readLine(in);
      if (reqLine == null || reqLine.isEmpty()) return;
      String[] p = reqLine.split(" ");
      String method = p[0], fullPath = p.length > 1 ? p[1] : "/";
      int len = 0; String line;
      while ((line = readLine(in)) != null && !line.isEmpty()) {
        if (line.toLowerCase().startsWith("content-length:")) len = Integer.parseInt(line.substring(15).trim());
      }
      String body = "";
      if (len > 0) {
        byte[] b = new byte[len]; int off = 0;
        while (off < len) { int r = in.read(b, off, len - off); if (r == -1) break; off += r; }
        body = new String(b, 0, off, StandardCharsets.UTF_8);
      }
      if ("OPTIONS".equalsIgnoreCase(method)) { send(out, 204, ""); return; }
      String path = fullPath.contains("?") ? fullPath.substring(0, fullPath.indexOf("?")) : fullPath;

      if ("GET".equalsIgnoreCase(method) && (path.equals("/") || path.equals("/health"))) {
        JSONObject r = new JSONObject();
        r.put("ok", true);
        r.put("version", "8.0-omnipotent");
        r.put("accessibility", LuxAccessibilityService.instance != null ? "ON" : "OFF");
        JSONObject px = new JSONObject();
        px.put("tor_socks5h", checkPort("127.0.0.1", 9050));
        px.put("i2pd_http", checkPort("127.0.0.1", 4444));
        r.put("proxies", px);
        send(out, 200, r.toString()); return;
      }
      if ("GET".equalsIgnoreCase(method) && path.equals("/phone/screen")) {
        if (LuxAccessibilityService.instance == null) {
          send(out, 200, "{\"ok\":false,\"error\":\"Ative Acessibilidade em Config 2B\"}");
        } else {
          send(out, 200, LuxAccessibilityService.instance.dumpScreen().toString());
        }
        return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/phone/action")) {
        send(out, 200, handlePhoneAction(new JSONObject(body)).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/search")) {
        send(out, 200, searchAll(new JSONObject(body).optString("query", "").trim()).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/inspect")) {
        send(out, 200, inspectUrl(new JSONObject(body).optString("url", "").trim()).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/llm/cloud")) {
        send(out, 200, askCloudLlm(new JSONObject(body)).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/media/cloud")) {
        send(out, 200, generateCloudMedia(new JSONObject(body)).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/colab/sync")) {
        send(out, 200, discoverColabUrl(new JSONObject(body).optString("channel", "lux-omega-kauan-v55")).toString()); return;
      }
      if ("POST".equalsIgnoreCase(method) && path.equals("/colab/proxy")) {
        JSONObject req = new JSONObject(body);
        String colabUrl = req.optString("colab_url", "").replaceAll("/+$", "");
        String endpoint = req.optString("endpoint", "/run");
        String payload = req.optJSONObject("payload") != null ? req.getJSONObject("payload").toString() : "{}";
        if (colabUrl.isEmpty()) {
          send(out, 200, new JSONObject().put("ok", false).put("wake_required", true).put("error", "Colab dormindo.").toString());
          return;
        }
        try {
          send(out, 200, postHttp(colabUrl + endpoint, payload, null, 240000));
        } catch (Exception e) {
          send(out, 200, new JSONObject().put("ok", false).put("wake_required", true).put("error", "Colab offline: " + e.getMessage()).toString());
        }
        return;
      }
      send(out, 404, "{\"ok\":false}");
    } catch (Exception ignored) {}
  }

  private JSONObject handlePhoneAction(JSONObject req) {
    JSONObject out = new JSONObject();
    try {
      LuxAccessibilityService svc = LuxAccessibilityService.instance;
      if (svc == null) return out.put("ok", false).put("error", "Serviço de Acessibilidade desativado.");
      String act = req.optString("action", "");
      String val = req.optString("value", "");
      boolean ok = false;
      if ("open_app".equals(act)) ok = svc.launchAppByName(val);
      else if ("click_text".equals(act)) ok = svc.clickByText(val);
      else if ("type_text".equals(act)) ok = svc.typeIntoFocusedOrEditable(val);
      else if ("swipe".equals(act)) ok = svc.swipeScreen(val);
      else if ("back".equals(act)) ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
      else if ("home".equals(act)) ok = svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
      return out.put("ok", ok).put("action", act).put("value", val);
    } catch (Exception e) {
      try { return out.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) { return out; }
    }
  }

  private JSONObject askCloudLlm(JSONObject req) {
    JSONObject out = new JSONObject();
    try {
      String prompt = req.optString("prompt", "").trim();
      String apiKey = req.optString("api_key", "").trim();
      String provider = req.optString("provider", "pollinations").toLowerCase();
      if (apiKey.isEmpty() || provider.equals("pollinations")) {
        String raw = getHttp("https://text.pollinations.ai/" + URLEncoder.encode(prompt, "UTF-8") + "?model=openai-large", null);
        return out.put("ok", true).put("provider", "Cloud LLM (Grátis)").put("text", raw);
      }
      String url = provider.equals("groq") ? "https://api.groq.com/openai/v1/chat/completions" : "https://openrouter.ai/api/v1/chat/completions";
      String model = provider.equals("groq") ? "llama-3.3-70b-versatile" : "deepseek/deepseek-r1:free";
      JSONObject msg = new JSONObject().put("role", "user").put("content", prompt);
      JSONObject body = new JSONObject().put("model", model).put("messages", new JSONArray().put(msg));
      String res = postHttp(url, body.toString(), "Bearer " + apiKey, 30000);
      String txt = new JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
      return out.put("ok", true).put("provider", provider.toUpperCase() + " (" + model + ")").put("text", txt);
    } catch (Exception e) {
      try { return out.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) { return out; }
    }
  }

  private JSONObject discoverColabUrl(String channel) {
    JSONObject out = new JSONObject();
    try {
      String raw = getHttp("https://ntfy.sh/" + URLEncoder.encode(channel, "UTF-8") + "/json?poll=1&since=12h", null);
      String found = "";
      for (String line : raw.split("\n")) {
        if (line.trim().isEmpty()) continue;
        String m = new JSONObject(line).optString("message", "").trim();
        if (m.startsWith("https://") && m.contains("trycloudflare.com")) found = m;
      }
      if (!found.isEmpty() && getHttp(found + "/health", null).contains("\"ok\":true")) {
        return out.put("ok", true).put("url", found);
      }
      return out.put("ok", false).put("wake_required", true);
    } catch (Exception e) {
      try { return out.put("ok", false).put("wake_required", true); } catch (Exception ignored) { return out; }
    }
  }

  private JSONObject generateCloudMedia(JSONObject req) {
    JSONObject out = new JSONObject();
    try {
      String provider = req.optString("provider", "pollinations").toLowerCase();
      String prompt = req.optString("prompt", "").trim();
      String apiKey = req.optString("api_key", "").trim();
      String mode = req.optString("mode", "image");
      if (provider.equals("pollinations") || apiKey.isEmpty()) {
        String imgUrl = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8") + "?model=flux&width=1280&height=720&nologo=true&seed=" + (System.currentTimeMillis() % 99999);
        return out.put("ok", true).put("type", "image").put("provider", "Flux HD (Grátis)").put("url", imgUrl);
      }
      if (provider.equals("fal")) {
        String model = mode.equals("video") ? "fal-ai/kling-video/v2/master/text-to-video" : "fal-ai/flux-pro/v1.1";
        String res = postHttp("https://queue.fal.run/" + model, new JSONObject().put("prompt", prompt).toString(), "Key " + apiKey, 30000);
        JSONObject j = new JSONObject(res);
        String url = j.has("video") ? j.getJSONObject("video").optString("url", "") : (j.has("images") ? j.getJSONArray("images").getJSONObject(0).optString("url", "") : "");
        return out.put("ok", true).put("type", mode).put("provider", "Fal.ai Pro").put("url", url);
      }
      return out.put("ok", false).put("error", "Provedor inválido.");
    } catch (Exception e) {
      try { return out.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) { return out; }
    }
  }

  private String readLine(InputStream in) throws IOException {
    ByteArrayOutputStream b = new ByteArrayOutputStream(); int ch;
    while ((ch = in.read()) != -1) {
      if (ch == '\r') { in.mark(1); if (in.read() != '\n') in.reset(); break; }
      if (ch == '\n') break; b.write(ch);
    }
    return (ch == -1 && b.size() == 0) ? null : b.toString("UTF-8");
  }

  private void send(OutputStream out, int st, String json) throws IOException {
    byte[] d = json.getBytes(StandardCharsets.UTF_8);
    String h = "HTTP/1.1 " + st + " OK\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET,POST,OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type,Authorization\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: " + d.length + "\r\nConnection: close\r\n\r\n";
    out.write(h.getBytes(StandardCharsets.UTF_8));
    if (d.length > 0) out.write(d);
    out.flush();
  }

  private JSONObject checkPort(String h, int p) {
    JSONObject j = new JSONObject(); long t = System.nanoTime();
    try (Socket s = new Socket()) {
      s.connect(new InetSocketAddress(h, p), 1200);
      j.put("status", "ON"); j.put("latency_ms", Math.round((System.nanoTime() - t) / 100000.0) / 10.0);
    } catch (Exception e) { try { j.put("status", "OFF"); } catch (Exception ignored) {} }
    return j;
  }

  private JSONObject searchAll(String q) throws Exception {
    long t = System.nanoTime();
    JSONArray ddg = new JSONArray(), wiki = new JSONArray();
    try {
      String raw = getHttp("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"), null);
      Matcher m = Pattern.compile("<a[^>]+class=\"result__a\"[^>]+href=\"([^\"]+)\"[^>]*>(.*?)</a>", Pattern.DOTALL).matcher(raw);
      while (m.find() && ddg.length() < 6) {
        String href = m.group(1);
        if (href.contains("uddg=")) { int i = href.indexOf("uddg=") + 5, e = href.indexOf("&", i); href = URLDecoder.decode(e > 0 ? href.substring(i, e) : href.substring(i), "UTF-8"); }
        ddg.put(new JSONObject().put("title", clean(m.group(2))).put("url", href).put("source", "DuckDuckGo"));
      }
    } catch (Exception ignored) {}
    try {
      String raw = getHttp("https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=" + URLEncoder.encode(q, "UTF-8") + "&srlimit=3&format=json", null);
      JSONArray arr = new JSONObject(raw).getJSONObject("query").getJSONArray("search");
      for (int i = 0; i < arr.length(); i++) {
        String title = arr.getJSONObject(i).optString("title");
        wiki.put(new JSONObject().put("title", title + " (Wikipedia)").put("url", "https://pt.wikipedia.org/wiki/" + URLEncoder.encode(title.replace(" ", "_"), "UTF-8")).put("source", "Wikipedia"));
      }
    } catch (Exception ignored) {}
    JSONObject layers = new JSONObject().put("Surface Web", ddg).put("Enciclopédia / OSINT", wiki);
    return new JSONObject().put("ok", true).put("total_results", ddg.length() + wiki.length()).put("elapsed_ms", Math.round((System.nanoTime() - t) / 100000.0) / 10.0).put("by_layer", layers);
  }

  private JSONObject inspectUrl(String u) {
    if (!u.matches("(?i)^https?://.*")) u = "http://" + u;
    String route = "Surface / Direto";
    try {
      URL parsed = new URL(u);
      String host = parsed.getHost().toLowerCase();
      String html;
      if (host.endsWith(".onion")) { route = "Tor SOCKS5h (Orbot 127.0.0.1:9050)"; html = fetchSocks5h(parsed); }
      else if (host.endsWith(".i2p")) { route = "I2Pd HTTP (127.0.0.1:4444)"; html = getHttp(u, new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 4444))); }
      else { html = getHttp(u, null); }
      Matcher tm = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html);
      String title = tm.find() ? clean(tm.group(1)) : "";
      String txt = clean(html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " "));
      if (txt.length() > 4000) txt = txt.substring(0, 4000);
      return new JSONObject().put("ok", true).put("url", u).put("route", route).put("status_code", 200).put("title", title).put("clean_text", txt);
    } catch (Exception e) {
      try { return new JSONObject().put("ok", false).put("url", u).put("route", route).put("error", e.getMessage()); } catch (Exception ignored) { return new JSONObject(); }
    }
  }

  private String getHttp(String u, Proxy p) throws IOException {
    URL url = new URL(u);
    HttpURLConnection c = (HttpURLConnection) (p != null ? url.openConnection(p) : url.openConnection());
    c.setConnectTimeout(15000); c.setReadTimeout(20000);
    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) LUX-Omega/8.0");
    InputStream is = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
    return is == null ? "" : readAll(is);
  }

  private String postHttp(String u, String jsonBody, String authHeader, int timeout) throws IOException {
    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
    c.setRequestMethod("POST"); c.setDoOutput(true);
    c.setConnectTimeout(timeout); c.setReadTimeout(timeout);
    c.setRequestProperty("Content-Type", "application/json");
    if (authHeader != null && !authHeader.isEmpty()) c.setRequestProperty("Authorization", authHeader);
    c.getOutputStream().write(jsonBody.getBytes(StandardCharsets.UTF_8));
    InputStream is = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
    return is == null ? "" : readAll(is);
  }

  private String fetchSocks5h(URL url) throws Exception {
    String host = url.getHost();
    boolean ssl = "https".equalsIgnoreCase(url.getProtocol());
    int port = url.getPort() != -1 ? url.getPort() : (ssl ? 443 : 80);
    String path = (url.getPath() == null || url.getPath().isEmpty()) ? "/" : url.getPath();
    if (url.getQuery() != null) path += "?" + url.getQuery();
    Socket s = new Socket(); s.connect(new InetSocketAddress("127.0.0.1", 9050), 10000); s.setSoTimeout(25000);
    OutputStream out = s.getOutputStream(); InputStream in = s.getInputStream();
    out.write(new byte[]{5, 1, 0}); out.flush();
    byte[] g = new byte[2]; readFully(in, g);
    byte[] hb = host.getBytes(StandardCharsets.UTF_8);
    ByteArrayOutputStream req = new ByteArrayOutputStream();
    req.write(5); req.write(1); req.write(0); req.write(3); req.write(hb.length); req.write(hb);
    req.write((port >> 8) & 0xFF); req.write(port & 0xFF);
    out.write(req.toByteArray()); out.flush();
    byte[] rep = new byte[4]; readFully(in, rep);
    if (rep[1] != 0) { s.close(); throw new IOException("Erro Orbot SOCKS5: " + rep[1]); }
    if (rep[3] == 1) readFully(in, new byte[6]);
    else if (rep[3] == 3) readFully(in, new byte[in.read() + 2]);
    else if (rep[3] == 4) readFully(in, new byte[18]);
    Socket act = ssl ? ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(s, host, port, true) : s;
    if (ssl) ((SSLSocket) act).startHandshake();
    String http = "GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n";
    act.getOutputStream().write(http.getBytes(StandardCharsets.UTF_8));
    String raw = readAll(act.getInputStream()); act.close();
    int idx = raw.indexOf("\r\n\r\n");
    return idx > 0 ? raw.substring(idx + 4) : raw;
  }

  private void readFully(InputStream in, byte[] b) throws IOException { int o = 0; while (o < b.length) { int r = in.read(b, o, b.length - o); if (r == -1) throw new IOException("EOF"); o += r; } }
  private String readAll(InputStream in) throws IOException { ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int r; while ((r = in.read(buf)) != -1) b.write(buf, 0, r); return b.toString("UTF-8"); }
  private String clean(String s) { return s == null ? "" : s.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim(); }
}
