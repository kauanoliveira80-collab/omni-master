package com.luxomega.iceberg;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

public class LuxAccessibilityService extends AccessibilityService {
  public static volatile LuxAccessibilityService instance;

  @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
  @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
  @Override public void onInterrupt() {}
  @Override public boolean onUnbind(Intent intent) { instance = null; return super.onUnbind(intent); }

  public JSONObject dumpScreen() {
    JSONObject out = new JSONObject();
    JSONArray nodes = new JSONArray();
    try {
      AccessibilityNodeInfo root = getRootInActiveWindow();
      if (root == null) return out.put("ok", false).put("error", "Tela inacessível.");
      out.put("package", root.getPackageName() != null ? root.getPackageName().toString() : "");
      collectNodes(root, nodes, 0);
      out.put("ok", true).put("elements", nodes);
    } catch (Exception e) {
      try { out.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
    }
    return out;
  }

  private void collectNodes(AccessibilityNodeInfo node, JSONArray arr, int depth) {
    if (node == null || depth > 14 || arr.length() >= 80) return;
    CharSequence txt = node.getText();
    CharSequence desc = node.getContentDescription();
    boolean clickable = node.isClickable();
    boolean editable = node.isEditable();
    if ((txt != null && txt.length() > 0) || (desc != null && desc.length() > 0) || clickable || editable) {
      try {
        JSONObject item = new JSONObject();
        if (txt != null) item.put("text", txt.toString());
        if (desc != null) item.put("desc", desc.toString());
        item.put("clickable", clickable);
        item.put("editable", editable);
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        item.put("center_x", r.centerX());
        item.put("center_y", r.centerY());
        arr.put(item);
      } catch (Exception ignored) {}
    }
    for (int i = 0; i < node.getChildCount(); i++) collectNodes(node.getChild(i), arr, depth + 1);
  }

  public boolean clickByText(String query) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return false;
    return findAndClick(root, query.toLowerCase());
  }

  private boolean findAndClick(AccessibilityNodeInfo node, String q) {
    if (node == null) return false;
    String t = node.getText() != null ? node.getText().toString().toLowerCase() : "";
    String d = node.getContentDescription() != null ? node.getContentDescription().toString().toLowerCase() : "";
    if ((!t.isEmpty() && t.contains(q)) || (!d.isEmpty() && d.contains(q))) {
      AccessibilityNodeInfo target = node;
      while (target != null && !target.isClickable()) target = target.getParent();
      if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
      Rect r = new Rect();
      node.getBoundsInScreen(r);
      return tapCoords(r.centerX(), r.centerY());
    }
    for (int i = 0; i < node.getChildCount(); i++) {
      if (findAndClick(node.getChild(i), q)) return true;
    }
    return false;
  }

  public boolean typeIntoFocusedOrEditable(String text) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return false;
    AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (focused != null && focused.isEditable()) {
      Bundle args = new Bundle();
      args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
      return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }
    return findAndType(root, text);
  }

  private boolean findAndType(AccessibilityNodeInfo node, String text) {
    if (node == null) return false;
    if (node.isEditable()) {
      Bundle args = new Bundle();
      args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
      return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }
    for (int i = 0; i < node.getChildCount(); i++) {
      if (findAndType(node.getChild(i), text)) return true;
    }
    return false;
  }

  public boolean tapCoords(float x, float y) {
    Path p = new Path();
    p.moveTo(x, y);
    GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 60);
    return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
  }

  public boolean swipeScreen(String dir) {
    Path p = new Path();
    if ("up".equalsIgnoreCase(dir)) { p.moveTo(540, 500); p.lineTo(540, 1600); }
    else { p.moveTo(540, 1600); p.lineTo(540, 500); }
    GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, 280);
    return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
  }

  public boolean launchAppByName(String appQuery) {
    PackageManager pm = getPackageManager();
    String q = appQuery.toLowerCase().trim();
    List<ApplicationInfo> apps = pm.getInstalledApplications(0);
    for (ApplicationInfo info : apps) {
      String label = pm.getApplicationLabel(info).toString().toLowerCase();
      if (label.contains(q) || info.packageName.toLowerCase().contains(q)) {
        Intent launch = pm.getLaunchIntentForPackage(info.packageName);
        if (launch != null) {
          launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          startActivity(launch);
          return true;
        }
      }
    }
    return false;
  }
}
