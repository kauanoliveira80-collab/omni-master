# === LUX-Ω (v8.0 OMNIPOTENT) — ESTÚDIO 3D, VÍDEO CONSISTENTE, RAG & GPU AUTO-SCALING ===
import os, sys, gc, time, json, re, shutil, sqlite3, hashlib, threading, subprocess, urllib.request
from pathlib import Path

os.environ["COQUI_TOS_AGREED"] = "1"
SYNC_CHANNEL = "lux-omega-kauan-v55"  # Mesmo canal no Config 2B do APK
IDLE_TIMEOUT_MIN = 15

try:
    from google.colab import drive
    drive.mount('/content/drive', force_remount=False)
    WORK_DIR = Path("/content/drive/MyDrive/LUX_OMEGA_v80")
except Exception:
    WORK_DIR = Path("/content/LUX_OMEGA_v80")

for sub in ["outputs", "samples", "models", "hf_cache", "db"]:
    (WORK_DIR / sub).mkdir(parents=True, exist_ok=True)

os.environ["HF_HOME"] = str(WORK_DIR / "hf_cache")
os.environ["TORCH_HOME"] = str(WORK_DIR / "hf_cache" / "torch")

os.system("pip install -q fastapi uvicorn python-multipart httpx beautifulsoup4 trafilatura pypdf pandas yt-dlp edge-tts duckduckgo-search numpy pillow")
if not Path("/usr/local/bin/cloudflared").exists():
    os.system("wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared")

ACT_FILE = Path("/tmp/lux_last_act")
ACT_FILE.write_text(str(time.time()))

def idle_watchdog():
    while True:
        time.sleep(30)
        try:
            last = float(ACT_FILE.read_text().strip())
        except Exception:
            last = time.time()
        if time.time() - last > IDLE_TIMEOUT_MIN * 60:
            print(f"\n[LUX-Ω v8.0] Ocioso por {IDLE_TIMEOUT_MIN} min. Desligando GPU...")
            try:
                from google.colab import runtime
                runtime.unassign()
            except Exception:
                os._exit(0)

threading.Thread(target=idle_watchdog, daemon=True).start()

server_code = r"""
import os, gc, re, time, json, shutil, sqlite3, hashlib, asyncio, subprocess, urllib.request, urllib.parse
import numpy as np
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

os.environ["COQUI_TOS_AGREED"] = "1"
WORK_DIR = Path("__WORK_DIR__")
os.environ["HF_HOME"] = str(WORK_DIR / "hf_cache")
os.environ["TORCH_HOME"] = str(WORK_DIR / "hf_cache" / "torch")
ACT_FILE = Path("/tmp/lux_last_act")
DB_PATH = WORK_DIR / "db" / "lux_memory.sqlite"

app = FastAPI(title="LUX-Omega v8.0 Omnipotent Backend")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/files", StaticFiles(directory=str(WORK_DIR / "outputs")), name="files")

@app.middleware("http")
async def track_activity(request: Request, call_next):
    ACT_FILE.write_text(str(time.time()))
    return await call_next(request)

PUBLIC_URL = ""

def get_vram_gb():
    try:
        import torch
        if torch.cuda.is_available():
            return round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 1)
    except Exception:
        pass
    return 0.0

def get_free_vram_gb():
    try:
        import torch
        if torch.cuda.is_available():
            free_b, _ = torch.cuda.mem_get_info(0)
            return round(free_b / (1024**3), 2)
    except Exception:
        pass
    return 0.0

VRAM_GB = get_vram_gb()
IS_A100_80 = VRAM_GB >= 70.0
IS_A100 = VRAM_GB >= 35.0

_model_cache = {}
_model_vram_est = {
    "wan22_a14b": 31.5,
    "wan22_i2v": 32.0,
    "qwq_32b": 35.8,
    "wan_cinema": 13.8,
    "wan_i2v_t4": 13.8,
    "qwen25_14b": 11.2,
    "xtts_v2": 4.2,
    "insightface": 2.4,
    "whisper_turbo": 3.1,
    "embedder_minilm": 0.5,
}

def smart_get_model(tag, loader_fn):
    if tag in _model_cache:
        obj = _model_cache.pop(tag)
        _model_cache[tag] = obj
        return obj
    needed = _model_vram_est.get(tag, 8.0) + 2.5
    while _model_cache and (not IS_A100 or get_free_vram_gb() < needed):
        _, old_obj = _model_cache.popitem(last=False)
        del old_obj
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
    obj = loader_fn()
    _model_cache[tag] = obj
    return obj

def enhance_faces_hd(video_or_img_path, out_path, is_video=True):
    try:
        subprocess.run(["pip", "install", "-q", "gfpgan", "realesrgan"], check=False)
        import cv2
        from gfpgan import GFPGANer
        enhancer = GFPGANer(
            model_path="https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.4.pth",
            upscale=1, arch="clean", channel_multiplier=2
        )
        if not is_video:
            img = cv2.imread(str(video_or_img_path))
            _, _, restored = enhancer.enhance(img, has_aligned=False, only_center_face=False, paste_back=True)
            cv2.imwrite(str(out_path), restored)
            return True
        cap = cv2.VideoCapture(str(video_or_img_path))
        fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
        w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        tmp_hd = Path(str(out_path) + "_raw.mp4")
        writer = cv2.VideoWriter(str(tmp_hd), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            _, _, restored = enhancer.enhance(frame, has_aligned=False, only_center_face=False, paste_back=True)
            writer.write(restored)
        cap.release()
        writer.release()
        subprocess.run(["ffmpeg", "-y", "-i", str(tmp_hd), "-i", str(video_or_img_path), "-c:v", "libx264", "-crf", "17", "-map", "0:v:0", "-map", "1:a:0?", "-shortest", str(out_path)], check=True)
        return True
    except Exception:
        shutil.copy(video_or_img_path, out_path)
        return False

# === MEMÓRIA VETORIAL PERSISTENTE (RAG) NO GOOGLE DRIVE ===
def init_memory_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("CREATE TABLE IF NOT EXISTS chunks (id TEXT PRIMARY KEY, source TEXT, content TEXT, embedding BLOB, created_at REAL)")
    conn.commit()
    conn.close()

init_memory_db()

def get_embedder():
    def load_emb():
        subprocess.run(["pip", "install", "-q", "sentence-transformers"], check=False)
        from sentence_transformers import SentenceTransformer
        return SentenceTransformer("sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2", device="cpu")
    return smart_get_model("embedder_minilm", load_emb)

def index_to_drive_rag(source: str, text: str) -> int:
    clean_t = re.sub(r"\s+", " ", text).strip()
    if not clean_t:
        return 0
    pieces = [clean_t[i:i+750] for i in range(0, len(clean_t), 630)]
    emb_model = get_embedder()
    vecs = emb_model.encode(pieces, normalize_embeddings=True)
    conn = sqlite3.connect(str(DB_PATH))
    now = time.time()
    for piece, vec in zip(pieces, vecs):
        cid = hashlib.sha256(f"{source}:{piece}".encode("utf-8")).hexdigest()[:24]
        conn.execute("INSERT OR REPLACE INTO chunks VALUES (?, ?, ?, ?, ?)", (cid, source, piece, np.asarray(vec, dtype=np.float32).tobytes(), now))
    conn.commit()
    conn.close()
    return len(pieces)

def search_drive_rag(query: str, top_k: int = 5):
    conn = sqlite3.connect(str(DB_PATH))
    rows = conn.execute("SELECT source, content, embedding FROM chunks").fetchall()
    conn.close()
    if not rows:
        return []
    emb_model = get_embedder()
    q_vec = np.asarray(emb_model.encode([query], normalize_embeddings=True)[0], dtype=np.float32)
    scored = []
    for src, content, blob in rows:
        vec = np.frombuffer(blob, dtype=np.float32)
        if vec.shape == q_vec.shape:
            scored.append((float(np.dot(q_vec, vec)), src, content))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:top_k]

@app.get("/health")
async def health():
    return {"ok": True, "version": "8.0-omnipotent", "gpu_vram_gb": VRAM_GB, "loaded": list(_model_cache.keys()), "url": PUBLIC_URL}

@app.post("/memory/ingest")
async def memory_ingest(source: str = Form("Nota Manual"), text: str = Form(""), file: Optional[UploadFile] = File(None)):
    extracted = text.strip()
    src_label = source.strip() or "Nota Manual"
    if file is not None and file.filename:
        src_label = file.filename
        ext = Path(file.filename).suffix.lower()
        tmp_f = WORK_DIR / "samples" / f"rag_{int(time.time())}{ext}"
        with open(tmp_f, "wb") as f:
            shutil.copyfileobj(file.file, f)
        if ext == ".pdf":
            from pypdf import PdfReader
            extracted += "\n" + "\n".join([p.extract_text() or "" for p in PdfReader(str(tmp_f)).pages])
        else:
            extracted += "\n" + tmp_f.read_text(encoding="utf-8", errors="ignore")
    if not extracted.strip():
        return {"ok": False, "error": "Envie texto ou anexe PDF/TXT/MD/CSV em 📎."}
    return {"ok": True, "source": src_label, "chunks_indexed": index_to_drive_rag(src_label, extracted)}

@app.post("/memory/query")
async def memory_query(req: Request):
    data = await req.json()
    question = data.get("query", "").strip()
    hits = search_drive_rag(question, top_k=5)
    if not hits:
        return {"ok": True, "answer": "A memória no Drive ainda está vazia. Use 'memorizar <texto>' ou anexe um PDF.", "sources": []}
    ctx = "\n\n".join([f"[Fonte: {src}]\n{txt}" for _, src, txt in hits])
    rag_prompt = f"Responda com base nos documentos recuperados abaixo e cite as fontes:\n\n{ctx}\n\nPERGUNTA: {question}"
    import torch
    from transformers import pipeline, BitsAndBytesConfig
    if IS_A100:
        gen = smart_get_model("qwq_32b", lambda: pipeline("text-generation", model="Qwen/QwQ-32B", torch_dtype=torch.bfloat16, device_map="auto") if IS_A100_80 else pipeline("text-generation", model="Qwen/QwQ-32B", model_kwargs={"quantization_config": BitsAndBytesConfig(load_in_8bit=True)}, device_map="auto"))
    else:
        gen = smart_get_model("qwen25_14b", lambda: pipeline("text-generation", model="Qwen/Qwen2.5-14B-Instruct", model_kwargs={"quantization_config": BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)}, device_map="auto"))
    out = gen([{"role": "user", "content": rag_prompt}], max_new_tokens=1024)
    return {"ok": True, "answer": out[0]["generated_text"][-1]["content"], "sources": [{"source": s, "score": round(sc, 3), "snippet": t[:160] + "..."} for sc, s, t in hits]}

# 1. CLONAGEM DE VOZ STUDIO 4-ESTÁGIOS
@app.post("/voice_clone")
async def voice_clone(text: str = Form(...), language: str = Form("pt"), engine: str = Form("f5"), media_url: str = Form(""), file: Optional[UploadFile] = File(None)):
    ts = int(time.time())
    raw_in = WORK_DIR / "samples" / f"raw_{ts}"
    wav_trim = WORK_DIR / "samples" / f"trim_{ts}.wav"
    clean_wav = WORK_DIR / "samples" / f"ref_{ts}.wav"
    if file is not None and file.filename:
        raw_in = raw_in.with_suffix(Path(file.filename).suffix or ".mp4")
        with open(raw_in, "wb") as f:
            shutil.copyfileobj(file.file, f)
    elif media_url.strip():
        raw_in = raw_in.with_suffix(".mp4")
        subprocess.run(["yt-dlp", "-f", "bestaudio/best", "-o", str(raw_in), media_url.strip()], check=True)
    else:
        return {"ok": False, "error": "Anexe áudio/vídeo em 📎 ou informe um link."}

    subprocess.run(["ffmpeg", "-y", "-i", str(raw_in), "-vn", "-af", "highpass=f=80,silenceremove=start_periods=1:start_silence=0.1:start_threshold=-45dB,loudnorm", "-acodec", "pcm_s16le", "-ar", "24000", "-ac", "1", "-t", "15", str(wav_trim)], check=True)
    ref_audio = wav_trim
    try:
        subprocess.run(["pip", "install", "-q", "demucs"], check=False)
        sep_dir = WORK_DIR / "samples" / f"sep_{ts}"
        subprocess.run(["demucs", "--two-stems=vocals", "-o", str(sep_dir), str(wav_trim)], check=True)
        vocals = list(sep_dir.rglob("vocals.wav"))
        if vocals:
            subprocess.run(["ffmpeg", "-y", "-i", str(vocals[0]), "-ar", "24000", "-ac", "1", str(clean_wav)], check=True)
            ref_audio = clean_wav
    except Exception:
        pass

    raw_out = WORK_DIR / "samples" / f"gen_{ts}.wav"
    out_name = f"studio_voice_{ts}.mp3"
    out_path = WORK_DIR / "outputs" / out_name
    if engine == "f5":
        subprocess.run(["pip", "install", "-q", "f5-tts", "faster-whisper"], check=False)
        ref_text = ""
        try:
            from faster_whisper import WhisperModel
            wm = WhisperModel("small", device="cuda", compute_type="float16")
            segs, _ = wm.transcribe(str(ref_audio))
            ref_text = " ".join([s.text.strip() for s in segs]).strip()
            del wm; gc.collect()
        except Exception:
            pass
        cmd = ["f5-tts_infer-cli", "--model", "F5TTS_v1_Base", "--ref_audio", str(ref_audio), "--gen_text", text, "--output_dir", str(WORK_DIR / "samples"), "--output_file", f"gen_{ts}.wav"]
        if ref_text:
            cmd.extend(["--ref_text", ref_text])
        subprocess.run(cmd, check=True)
    else:
        def load_xtts():
            subprocess.run(["pip", "install", "-q", "coqui-tts", "soundfile"], check=False)
            import torch
            from TTS.api import TTS
            return TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cuda" if torch.cuda.is_available() else "cpu")
        tts = smart_get_model("xtts_v2", load_xtts)
        tts.tts_to_file(text=text, speaker_wav=str(ref_audio), language=language, file_path=str(raw_out))

    subprocess.run(["ffmpeg", "-y", "-i", str(raw_out), "-af", "acompressor=threshold=-18dB:ratio=3:attack=5:release=50,loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "2", "-b:a", "192k", str(out_path)], check=True)
    return {"ok": True, "type": "audio", "url": f"{PUBLIC_URL}/files/{out_name}", "drive_path": str(out_path)}

# 2. FACE SWAP MULTI-ÂNGULO + GFPGAN HD
@app.post("/face_swap")
async def face_swap(target_name: str = Form(""), media_file: Optional[UploadFile] = File(None)):
    ts = int(time.time())
    if media_file is None or not media_file.filename:
        return {"ok": False, "error": "Anexe o vídeo ou imagem base em 📎."}
    base_ext = Path(media_file.filename).suffix.lower() or ".mp4"
    base_path = WORK_DIR / "samples" / f"base_{ts}{base_ext}"
    with open(base_path, "wb") as f:
        shutil.copyfileobj(media_file.file, f)

    subprocess.run(["pip", "install", "-q", "insightface", "onnxruntime-gpu", "opencv-python-headless"], check=False)
    model_path = WORK_DIR / "models" / "inswapper_128.onnx"
    if not model_path.exists():
        urllib.request.urlretrieve("https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx", str(model_path))

    def load_swapper():
        import insightface
        app_fa = insightface.app.FaceAnalysis(name="buffalo_l", providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
        app_fa.prepare(ctx_id=0, det_size=(640, 640))
        swapper = insightface.model_zoo.get_model(str(model_path), providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
        return (app_fa, swapper)

    app_fa, swapper = smart_get_model("insightface", load_swapper)
    import cv2
    from duckduckgo_search import DDGS
    embeddings, sample_face_obj = [], None
    with DDGS() as ddgs:
        imgs = list(ddgs.images(f"{target_name} closeup portrait face", max_results=10))
    for idx, im in enumerate(imgs):
        if len(embeddings) >= 4:
            break
        p = WORK_DIR / "samples" / f"f_{ts}_{idx}.jpg"
        try:
            urllib.request.urlretrieve(im["image"], str(p))
            img_cand = cv2.imread(str(p))
            if img_cand is not None:
                faces = app_fa.get(img_cand)
                if len(faces) == 1:
                    if sample_face_obj is None:
                        sample_face_obj = faces[0]
                    embeddings.append(faces[0].normed_embedding)
        except Exception:
            continue
    if not embeddings or sample_face_obj is None:
        return {"ok": False, "error": f"Rosto não encontrado para '{target_name}'."}

    mean_emb = np.mean(embeddings, axis=0)
    sample_face_obj.normed_embedding = mean_emb / np.linalg.norm(mean_emb)

    if base_ext not in [".mp4", ".mov", ".avi", ".mkv", ".webm"]:
        img_dst = cv2.imread(str(base_path))
        for f_dst in app_fa.get(img_dst):
            img_dst = swapper.get(img_dst, f_dst, sample_face_obj, paste_back=True)
        raw_img = WORK_DIR / "samples" / f"swap_raw_{ts}.jpg"
        cv2.imwrite(str(raw_img), img_dst)
        out_name = f"swap_hd_{ts}.jpg"
        out_path = WORK_DIR / "outputs" / out_name
        enhance_faces_hd(raw_img, out_path, is_video=False)
        return {"ok": True, "type": "image", "faces_fused": len(embeddings), "url": f"{PUBLIC_URL}/files/{out_name}"}

    cap = cv2.VideoCapture(str(base_path))
    fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    tmp_vid = WORK_DIR / "samples" / f"silent_{ts}.mp4"
    av_vid = WORK_DIR / "samples" / f"av_{ts}.mp4"
    out_name = f"swap_hd_{ts}.mp4"
    out_path = WORK_DIR / "outputs" / out_name
    writer = cv2.VideoWriter(str(tmp_vid), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        for f_dst in app_fa.get(frame):
            frame = swapper.get(frame, f_dst, sample_face_obj, paste_back=True)
        writer.write(frame)
    cap.release(); writer.release()
    subprocess.run(["ffmpeg", "-y", "-i", str(tmp_vid), "-i", str(base_path), "-c:v", "libx264", "-map", "0:v:0", "-map", "1:a:0?", "-shortest", str(av_vid)], check=True)
    enhance_faces_hd(av_vid, out_path, is_video=True)
    return {"ok": True, "type": "video", "faces_fused": len(embeddings), "url": f"{PUBLIC_URL}/files/{out_name}", "drive_path": str(out_path)}

# 3. DUBLAGEM STUDIO 3D (LIVEPORTRAIT + WAV2LIP + GFPGAN 1080p)
@app.post("/dub_video")
async def dub_video(text: str = Form(""), target_name: str = Form(""), language: str = Form("pt"), video_file: Optional[UploadFile] = File(None)):
    ts = int(time.time())
    if video_file is None or not video_file.filename:
        return {"ok": False, "error": "Anexe o vídeo ou foto-retrato base em 📎."}
    in_ext = Path(video_file.filename).suffix.lower() or ".mp4"
    in_path = WORK_DIR / "samples" / f"dub_in_{ts}{in_ext}"
    with open(in_path, "wb") as f:
        shutil.copyfileobj(video_file.file, f)

    current_vid = in_path
    if in_ext in [".jpg", ".jpeg", ".png", ".webp"]:
        lp_dir = WORK_DIR / "models" / "LivePortrait"
        if not lp_dir.exists():
            subprocess.run(["git", "clone", "-q", "https://github.com/KwaiVGI/LivePortrait.git", str(lp_dir)], check=True)
            subprocess.run(["pip", "install", "-q", "onnxruntime-gpu", "tyro", "rich", "albumentations"], check=False)
        driving_sample = lp_dir / "assets" / "examples" / "driving" / "d0.mp4"
        if driving_sample.exists():
            subprocess.run(["python3", str(lp_dir / "inference.py"), "-s", str(in_path), "-d", str(driving_sample), "-o", str(WORK_DIR / "samples")], check=False)
            gen_lp = list((WORK_DIR / "samples").glob("*.mp4"))
            if gen_lp:
                current_vid = sorted(gen_lp, key=lambda p: p.stat().st_mtime)[-1]

    if target_name.strip():
        with open(current_vid, "rb") as vf:
            from starlette.datastructures import UploadFile as StarletteUpload
            sw_res = await face_swap(target_name=target_name, media_file=StarletteUpload(filename="base.mp4", file=vf))
        if sw_res.get("ok") and sw_res.get("drive_path"):
            current_vid = Path(sw_res["drive_path"])

    if text.strip():
        ref_wav = WORK_DIR / "samples" / f"dub_ref_{ts}.wav"
        subprocess.run(["ffmpeg", "-y", "-i", str(in_path), "-vn", "-acodec", "pcm_s16le", "-ar", "22050", "-ac", "1", "-t", "20", str(ref_wav)], check=False)
        def load_xtts():
            subprocess.run(["pip", "install", "-q", "coqui-tts", "soundfile"], check=False)
            import torch
            from TTS.api import TTS
            return TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cuda" if torch.cuda.is_available() else "cpu")
        tts = smart_get_model("xtts_v2", load_xtts)
        cloned_wav = WORK_DIR / "samples" / f"dub_cloned_{ts}.wav"
        if ref_wav.exists() and ref_wav.stat().st_size > 1000:
            tts.tts_to_file(text=text.strip(), speaker_wav=str(ref_wav), language=language, file_path=str(cloned_wav))
        else:
            subprocess.run(["edge-tts", "--voice", "pt-BR-AntonioNeural", "--text", text.strip(), "--write-media", str(cloned_wav)], check=True)

        w2l_dir = WORK_DIR / "models" / "Wav2Lip"
        if not w2l_dir.exists():
            subprocess.run(["git", "clone", "-q", "https://github.com/Rudrabha/Wav2Lip.git", str(w2l_dir)], check=True)
            subprocess.run(["pip", "install", "-q", "librosa==0.9.2", "numba"], check=False)
            ckpt_dir = w2l_dir / "checkpoints"
            ckpt_dir.mkdir(exist_ok=True)
            urllib.request.urlretrieve("https://huggingface.co/Nekochu/Wav2Lip/resolve/main/wav2lip_gan.pth", str(ckpt_dir / "wav2lip_gan.pth"))

        raw_lip = WORK_DIR / "samples" / f"dub_lip_{ts}.mp4"
        subprocess.run(["python3", str(w2l_dir / "inference.py"), "--checkpoint_path", str(w2l_dir / "checkpoints" / "wav2lip_gan.pth"), "--face", str(current_vid), "--audio", str(cloned_wav), "--outfile", str(raw_lip)], check=True)
        out_name = f"dub_3d_1080p_{ts}.mp4"
        out_path = WORK_DIR / "outputs" / out_name
        enhance_faces_hd(raw_lip, out_path, is_video=True)
        return {"ok": True, "type": "video", "url": f"{PUBLIC_URL}/files/{out_name}", "drive_path": str(out_path)}

    return {"ok": True, "type": "video", "url": f"{PUBLIC_URL}/files/{current_vid.name}", "drive_path": str(current_vid)}

# 4. VÍDEO LONGO CONSISTENTE (I2V CHAINING) + CINEMA + LLM + WHISPER + CRAWL + PYTHON + MCP
@app.post("/run")
async def run_tool(req: Request):
    data = await req.json()
    tool = data.get("tool", "")
    params = data.get("params", {})
    ts = int(time.time())

    if tool == "video_story":
        scenes = [s.strip() for s in params.get("prompt", "").split("|") if s.strip()]
        if len(scenes) == 1:
            base = scenes[0]
            scenes = [f"{base}, establishing wide shot, consistent character", f"{base}, medium shot, continuing action, consistent face and outfit", f"{base}, cinematic closeup, consistent identity"]
        subprocess.run(["pip", "install", "-q", "diffusers", "transformers", "accelerate", "bitsandbytes", "imageio[ffmpeg]", "ftfy"], check=False)
        import torch
        from PIL import Image
        from diffusers.utils import export_to_video

        anchor_img_path = WORK_DIR / "samples" / f"anchor_{ts}.png"
        urllib.request.urlretrieve(f"https://image.pollinations.ai/prompt/{urllib.parse.quote(scenes[0] + ', photorealistic character portrait, 8k')}?model=flux&width=832&height=480&nologo=true", str(anchor_img_path))
        cond_image = Image.open(anchor_img_path).convert("RGB")

        def load_i2v():
            from diffusers import WanImageToVideoPipeline
            from diffusers.quantizers import PipelineQuantizationConfig
            q_cfg = PipelineQuantizationConfig(quant_backend="bitsandbytes_4bit", quant_kwargs={"load_in_4bit": True, "bnb_4bit_compute_dtype": torch.bfloat16})
            model_id = "Wan-AI/Wan2.2-I2V-A14B-Diffusers" if IS_A100 else "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers"
            pipe = WanImageToVideoPipeline.from_pretrained(model_id, quantization_config=q_cfg, torch_dtype=torch.bfloat16)
            if not IS_A100:
                pipe.enable_model_cpu_offload()
            else:
                pipe.to("cuda")
            return pipe

        pipe = smart_get_model("wan22_i2v" if IS_A100 else "wan_i2v_t4", load_i2v)
        clip_paths = []
        for idx, sc_prompt in enumerate(scenes[:4]):
            frames = pipe(image=cond_image, prompt=sc_prompt, height=480, width=832, num_frames=49, guidance_scale=5.0).frames[0]
            c_path = WORK_DIR / "samples" / f"scene_{ts}_{idx}.mp4"
            export_to_video(frames, str(c_path), fps=24)
            clip_paths.append(c_path)
            cond_image = frames[-1] if isinstance(frames[-1], Image.Image) else Image.fromarray(frames[-1])

        concat_txt = WORK_DIR / "samples" / f"concat_{ts}.txt"
        concat_txt.write_text("\n".join([f"file '{p}'" for p in clip_paths]))
        merged_raw = WORK_DIR / "samples" / f"story_raw_{ts}.mp4"
        subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_txt), "-c", "copy", str(merged_raw)], check=True)

        fname = f"story_consistent_1080p_{ts}.mp4"
        out_path = WORK_DIR / "outputs" / fname
        subprocess.run(["ffmpeg", "-y", "-i", str(merged_raw), "-vf", "scale=1920:1080:flags=lanczos,unsharp=5:5:0.8:3:3:0.4", "-c:v", "libx264", "-crf", "16", "-pix_fmt", "yuv420p", str(out_path)], check=True)
        return {"ok": True, "type": "video", "scenes_count": len(clip_paths), "url": f"{PUBLIC_URL}/files/{fname}"}

    if tool == "video_gpu":
        prompt = params.get("prompt", "Cinematic establishing shot, photorealistic, 8k")
        subprocess.run(["pip", "install", "-q", "diffusers", "transformers", "accelerate", "bitsandbytes", "imageio[ffmpeg]", "ftfy"], check=False)
        import torch
        from diffusers.utils import export_to_video
        if IS_A100:
            def load_wan22_a100():
                from diffusers import WanPipeline
                if IS_A100_80:
                    return WanPipeline.from_pretrained("Wan-AI/Wan2.2-T2V-A14B-Diffusers", torch_dtype=torch.bfloat16).to("cuda")
                from diffusers.quantizers import PipelineQuantizationConfig
                q_cfg = PipelineQuantizationConfig(quant_backend="bitsandbytes_4bit", quant_kwargs={"load_in_4bit": True, "bnb_4bit_compute_dtype": torch.bfloat16})
                return WanPipeline.from_pretrained("Wan-AI/Wan2.2-T2V-A14B-Diffusers", quantization_config=q_cfg, torch_dtype=torch.bfloat16).to("cuda")
            pipe = smart_get_model("wan22_a14b", load_wan22_a100)
            frames = pipe(prompt=prompt, height=720, width=1280, num_frames=81, guidance_scale=5.0).frames[0]
        else:
            def load_wan_t4():
                from diffusers import WanPipeline
                from diffusers.quantizers import PipelineQuantizationConfig
                q_cfg = PipelineQuantizationConfig(quant_backend="bitsandbytes_4bit", quant_kwargs={"load_in_4bit": True, "bnb_4bit_compute_dtype": torch.bfloat16})
                p = WanPipeline.from_pretrained("Wan-AI/Wan2.1-T2V-14B-Diffusers", quantization_config=q_cfg, torch_dtype=torch.bfloat16)
                p.enable_model_cpu_offload(); p.enable_vae_tiling()
                return p
            pipe = smart_get_model("wan_cinema", load_wan_t4)
            frames = pipe(prompt=prompt, height=480, width=832, num_frames=49, guidance_scale=5.5).frames[0]

        raw_vid = WORK_DIR / "samples" / f"vid_raw_{ts}.mp4"
        export_to_video(frames, str(raw_vid), fps=24)
        fname = f"cinema_1080p60_{ts}.mp4"
        out_path = WORK_DIR / "outputs" / fname
        subprocess.run(["ffmpeg", "-y", "-i", str(raw_vid), "-vf", "scale=1920:1080:flags=lanczos,unsharp=5:5:0.8:3:3:0.4,minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1", "-c:v", "libx264", "-crf", "16", "-preset", "fast", "-pix_fmt", "yuv420p", str(out_path)], check=True)
        return {"ok": True, "type": "video", "url": f"{PUBLIC_URL}/files/{fname}"}

    if tool == "llm_gpu":
        prompt = params.get("prompt", "")
        import torch
        from transformers import pipeline, BitsAndBytesConfig
        if IS_A100:
            gen = smart_get_model("qwq_32b", lambda: pipeline("text-generation", model="Qwen/QwQ-32B", torch_dtype=torch.bfloat16, device_map="auto") if IS_A100_80 else pipeline("text-generation", model="Qwen/QwQ-32B", model_kwargs={"quantization_config": BitsAndBytesConfig(load_in_8bit=True)}, device_map="auto"))
            out = gen([{"role": "user", "content": prompt}], max_new_tokens=2048)
        else:
            gen = smart_get_model("qwen25_14b", lambda: pipeline("text-generation", model="Qwen/Qwen2.5-14B-Instruct", model_kwargs={"quantization_config": BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)}, device_map="auto"))
            out = gen([{"role": "user", "content": prompt}], max_new_tokens=1536)
        return {"ok": True, "text": out[0]["generated_text"][-1]["content"]}

    if tool == "whisper":
        media_url = params.get("url", "")
        def load_whisper():
            subprocess.run(["pip", "install", "-q", "faster-whisper"], check=False)
            from faster_whisper import WhisperModel
            return WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")
        audio_file = WORK_DIR / "outputs" / f"aud_{ts}.mp3"
        subprocess.run(["yt-dlp", "-x", "--audio-format", "mp3", "-o", str(audio_file), media_url], check=True)
        model = smart_get_model("whisper_turbo", load_whisper)
        segs, info = model.transcribe(str(audio_file), beam_size=5)
        full_txt = " ".join([s.text.strip() for s in segs])
        index_to_drive_rag(media_url, full_txt)
        return {"ok": True, "language": info.language, "text": full_txt}

    if tool == "crawl4ai":
        url = params.get("url", "")
        subprocess.run(["pip", "install", "-q", "crawl4ai"], check=False)
        subprocess.run(["crawl4ai-setup"], check=False)
        from crawl4ai import AsyncWebCrawler
        async with AsyncWebCrawler() as crawler:
            res = await crawler.arun(url=url)
            md = res.markdown or ""
            index_to_drive_rag(url, md)
            return {"ok": True, "title": url, "clean_text": md[:8000]}

    if tool == "python":
        proc = subprocess.run(["python3", "-c", params.get("code", "")], capture_output=True, text=True, timeout=30)
        return {"ok": proc.returncode == 0, "stdout": proc.stdout, "stderr": proc.stderr}

    if tool == "mcp":
        srv = params.get("server", "npx -y @modelcontextprotocol/server-filesystem /content/drive/MyDrive")
        proc = subprocess.run(srv, input=json.dumps(params.get("rpc", {})), shell=True, capture_output=True, text=True, timeout=30)
        return {"ok": True, "stdout": proc.stdout, "stderr": proc.stderr}

    return {"ok": False, "error": f"Ferramenta desconhecida: {tool}"}
"""

server_code = server_code.replace("__WORK_DIR__", str(WORK_DIR))
Path("/content/lux_server.py").write_text(server_code)

uvicorn_proc = subprocess.Popen(["uvicorn", "lux_server:app", "--host", "127.0.0.1", "--port", "8765"], cwd="/content")
cf_proc = subprocess.Popen(["/usr/local/bin/cloudflared", "tunnel", "--url", "http://127.0.0.1:8765"], stderr=subprocess.PIPE, text=True)

tunnel_url = ""
for line in cf_proc.stderr:
    m = re.search(r"(https://[a-zA-Z0-9-]+\.trycloudflare\.com)", line)
    if m:
        tunnel_url = m.group(1)
        break

Path("/content/lux_server.py").write_text(server_code.replace('PUBLIC_URL = ""', f'PUBLIC_URL = "{tunnel_url}"'))
uvicorn_proc.terminate()
uvicorn_proc = subprocess.Popen(["uvicorn", "lux_server:app", "--host", "127.0.0.1", "--port", "8765"], cwd="/content")

print(f"\n✅ LUX-Ω v8.0 OMNIPOTENT ATIVO EM: {tunnel_url}")
try:
    req = urllib.request.Request(f"https://ntfy.sh/{SYNC_CHANNEL}", data=tunnel_url.encode(), method="POST")
    urllib.request.urlopen(req, timeout=5)
    print(f"📡 Sincronizado no canal: {SYNC_CHANNEL}")
except Exception as e:
    print("Aviso sync:", e)

while True:
    time.sleep(60)
